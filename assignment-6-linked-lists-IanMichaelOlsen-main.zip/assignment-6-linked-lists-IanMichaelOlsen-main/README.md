# Linked List Assignment 6
An implementation of a doubly linked list. 
